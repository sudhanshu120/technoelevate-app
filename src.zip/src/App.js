import Navbar from "./components/navbar/Navbar";
import { BrowserRouter as Router, Route, Switch } from "react-router-dom";
import "./App.css";
import UploadQuestionView from "./components/uploadQuestion/UploadQuestionView";
import SearchView from "./components/search/SearchView";

import Newheader from "./components/navbar/Newheader";
function App() {
  return (
    <Router>
      <div>
        {/* <Navbar/> */}
      
        <Newheader/>
      </div>

      <Switch>
          <Route exact path="/">
            <UploadQuestionView/>
          </Route>
          <Route exact path="/search">
            <SearchView/>
          </Route>
      </Switch>
    </Router>
  );
}

export default App;
