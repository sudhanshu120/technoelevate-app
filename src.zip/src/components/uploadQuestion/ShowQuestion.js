
import React from 'react'

function ShowQuestion({value}) {
    return (
        <div>
            <p>{value.question}</p>
        </div>
    )
}

export default ShowQuestion




